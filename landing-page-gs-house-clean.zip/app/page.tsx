import { TopBanner } from "@/components/top-banner"
import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { QuoteSimulator } from "@/components/quote-simulator"
import { Services } from "@/components/services"
import { Footer } from "@/components/footer"
import { FloatingWhatsApp } from "@/components/floating-whatsapp"

export default function Page() {
  return (
    <>
      <TopBanner />
      <Navbar />
      <main>
        <Hero />
        <QuoteSimulator />
        <Services />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </>
  )
}
